# Docker Login Credentials for wemoy Image Pull Secret
{{- define "wemogyCustomDomainDockerLogin" -}}
{{- .Values.images.wemogy.pullSecret.username }}:{{ .Values.images.wemogy.pullSecret.password }}
{{- end }}

{{- define "wemogyCustomDomainDockerLoginPullSecretContent" -}}
{
  "auths": {
    "https://wemogycloudacr.azurecr.io": {
        "auth": "{{ include "wemogyCustomDomainDockerLogin" . | b64enc }}"
    }
  }
}
{{- end }}
