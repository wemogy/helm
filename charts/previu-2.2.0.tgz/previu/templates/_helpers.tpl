# Docker Login Credentials for wemoy Image Pull Secret
{{- define "wemogyPreviuDockerLogin" -}}
{{- .Values.images.wemogy.pullSecret.username }}:{{ .Values.images.wemogy.pullSecret.password }}
{{- end }}

{{- define "wemogyPreviuDockerLoginPullSecretContent" -}}
{
  "auths": {
    "https://wemogycloudacr.azurecr.io": {
        "auth": "{{ include "wemogyPreviuDockerLogin" . | b64enc }}"
    }
  }
}
{{- end }}
