# Docker Login Credentials for wemogy Image Pull Secret
{{- define "billplaneDockerLogin" -}}
{{- .Values.images.wemogy.pullSecret.username }}:{{ .Values.images.wemogy.pullSecret.password }}
{{- end }}

{{- define "billplaneDockerLoginPullSecretContent" -}}
{
  "auths": {
    "https://{{ .Values.images.wemogy.pullSecret.registry }}": {
        "auth": "{{ include "billplaneDockerLogin" . | b64enc }}"
    }
  }
}
{{- end }}

{{/*
The one Secret Development / preview hosts read leftover credentials from. Named in one
place because the deployments reference it when those values are set. A deployed instance
does not use this Secret: Cosmos is managed identity, remaining secrets are Key Vault.
*/}}
{{- define "billplaneSecretName" -}}
{{ .Release.Name }}-billplane-secrets
{{- end }}

{{/*
The environment both backend hosts share.

API and Worker run the same composition root over the same database and the same instance
policy, so almost the whole configuration surface is common: persistence, product scope,
authentication, the notification webhook (the Worker delivers, the API answers
`retryNotificationDelivery`), the payment provider mode, the dunning policy, and the OTLP
collector. Host-specific keys are declared at the deployment that needs them — `Portal:*` and
the provider webhook secret on the API, `Worker:Scheduling` on the Worker, and each host's
Sentry DSN.

Optional values are emitted only when set, so an unset key falls through to the application's
own default rather than being overridden with an empty string. The Sentry DSN is per host
(`ApiSentryDsn` / `WorkerSentryDsn`) and is declared on that host's deployment, not here.
*/}}
{{- define "billplaneBackendEnv" -}}
- name: ASPNETCORE_ENVIRONMENT
  value: {{ .Values.settings.environment | quote }}
- name: Product__Key
  value: {{ .Values.settings.product.key | quote }}
- name: Cosmos__DatabaseName
  value: {{ .Values.settings.database.cosmos.databaseName | quote }}
{{- if .Values.settings.database.cosmos.accountEndpoint }}
- name: Cosmos__AccountEndpoint
  value: {{ .Values.settings.database.cosmos.accountEndpoint | quote }}
{{- end }}
{{- if .Values.settings.database.cosmos.connectionString }}
- name: Cosmos__ConnectionString
  valueFrom:
    secretKeyRef:
      name: {{ include "billplaneSecretName" . }}
      key: CosmosConnectionString
{{- end }}
{{- if .Values.settings.keyVault.uri }}
- name: KeyVault__Uri
  value: {{ .Values.settings.keyVault.uri | quote }}
{{- end }}
{{- if .Values.settings.identity.clientId }}
- name: AZURE_CLIENT_ID
  value: {{ .Values.settings.identity.clientId | quote }}
{{- end }}
- name: Authentication__Mode
  value: {{ .Values.settings.authentication.mode | quote }}
{{- if eq .Values.settings.authentication.mode "EntraId" }}
- name: Authentication__EntraId__TenantId
  value: {{ .Values.settings.authentication.entraId.tenantId | quote }}
- name: Authentication__EntraId__ClientId
  value: {{ .Values.settings.authentication.entraId.clientId | quote }}
- name: Authentication__EntraId__Audience
  value: {{ .Values.settings.authentication.entraId.audience | quote }}
{{- else if eq .Values.settings.authentication.mode "Oidc" }}
- name: Authentication__Oidc__Authority
  value: {{ .Values.settings.authentication.oidc.authority | quote }}
- name: Authentication__Oidc__Audience
  value: {{ .Values.settings.authentication.oidc.audience | quote }}
{{- if .Values.settings.authentication.oidc.metadataAddress }}
- name: Authentication__Oidc__MetadataAddress
  value: {{ .Values.settings.authentication.oidc.metadataAddress | quote }}
{{- end }}
{{- else if eq .Values.settings.authentication.mode "Development" }}
{{- range $index, $role := .Values.settings.authentication.development.roles }}
- name: Authentication__Development__Roles__{{ $index }}
  value: {{ $role | quote }}
{{- end }}
{{- end }}
{{- if .Values.settings.payments.mode }}
- name: Payments__Mode
  value: {{ .Values.settings.payments.mode | quote }}
{{- end }}
{{- if .Values.settings.payments.stripe.secretKey }}
- name: Payments__Stripe__SecretKey
  valueFrom:
    secretKeyRef:
      name: {{ include "billplaneSecretName" . }}
      key: PaymentsStripeSecretKey
{{- end }}
{{- if .Values.settings.payments.stripe.webhookSecret }}
- name: Payments__Stripe__WebhookSecret
  valueFrom:
    secretKeyRef:
      name: {{ include "billplaneSecretName" . }}
      key: PaymentsStripeWebhookSecret
{{- end }}
{{- if .Values.settings.payments.sevdesk.apiToken }}
- name: Payments__SevDesk__ApiToken
  valueFrom:
    secretKeyRef:
      name: {{ include "billplaneSecretName" . }}
      key: PaymentsSevDeskApiToken
{{- end }}
{{- if .Values.settings.payments.sevdesk.baseUrl }}
- name: Payments__SevDesk__BaseUrl
  value: {{ .Values.settings.payments.sevdesk.baseUrl | quote }}
{{- end }}
{{- if .Values.settings.notifications.webhook.endpoint }}
- name: Notifications__Webhook__Endpoint
  value: {{ .Values.settings.notifications.webhook.endpoint | quote }}
{{- end }}
{{- if .Values.settings.notifications.webhook.signingSecret }}
- name: Notifications__Webhook__SigningSecret
  valueFrom:
    secretKeyRef:
      name: {{ include "billplaneSecretName" . }}
      key: NotificationsWebhookSigningSecret
{{- end }}
- name: Notifications__Webhook__MaxDeliveryAttempts
  value: {{ .Values.settings.notifications.webhook.maxDeliveryAttempts | quote }}
- name: Notifications__Webhook__RequestTimeoutSeconds
  value: {{ .Values.settings.notifications.webhook.requestTimeoutSeconds | quote }}
- name: Notifications__Webhook__RetryIntervalSeconds
  value: {{ .Values.settings.notifications.webhook.retryIntervalSeconds | quote }}
{{- range $index, $seconds := .Values.settings.notifications.webhook.backoffSeconds }}
- name: Notifications__Webhook__BackoffSeconds__{{ $index }}
  value: {{ $seconds | quote }}
{{- end }}
{{- range $index, $type := .Values.settings.notifications.webhook.types }}
- name: Notifications__Webhook__Types__{{ $index }}
  value: {{ $type | quote }}
{{- end }}
- name: Billing__Dunning__PaymentTerms
  value: {{ .Values.settings.billing.dunning.paymentTerms | quote }}
- name: Billing__Dunning__RetryInterval
  value: {{ .Values.settings.billing.dunning.retryInterval | quote }}
- name: Billing__Dunning__MaxAttempts
  value: {{ .Values.settings.billing.dunning.maxAttempts | quote }}
- name: Billing__Dunning__TerminationDelay
  value: {{ .Values.settings.billing.dunning.terminationDelay | quote }}
{{- if .Values.settings.observability.sentryEnvironment }}
- name: SentryEnvironment
  value: {{ .Values.settings.observability.sentryEnvironment | quote }}
{{- else }}
- name: SentryEnvironment
  value: {{ .Values.settings.environment | quote }}
{{- end }}
{{- if .Values.settings.observability.otlp.collectorBaseUri }}
- name: OtlpCollectorBaseUri
  value: {{ .Values.settings.observability.otlp.collectorBaseUri | quote }}
{{- end }}
{{- if .Values.settings.observability.otlp.user }}
- name: OtlpUser
  value: {{ .Values.settings.observability.otlp.user | quote }}
{{- end }}
{{- if .Values.settings.observability.otlp.password }}
- name: OtlpPassword
  valueFrom:
    secretKeyRef:
      name: {{ include "billplaneSecretName" . }}
      key: OtlpPassword
{{- end }}
{{- end }}
