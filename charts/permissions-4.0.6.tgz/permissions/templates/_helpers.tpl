# Docker Login Credentials for wemoy Image Pull Secret
{{- define "spaceBlocksPermissionsDockerLogin" -}}
{{- .Values.images.wemogy.pullSecret.username }}:{{ .Values.images.wemogy.pullSecret.password }}
{{- end }}

{{- define "spaceBlocksPermissionsDockerLoginPullSecretContent" -}}
{
  "auths": {
    "https://wemogycloudacr.azurecr.io": {
        "auth": "{{ include "spaceBlocksPermissionsDockerLogin" . | b64enc }}"
    }
  }
}
{{- end }}
